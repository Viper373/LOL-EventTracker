package com.lol.loleventdatamanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LolEventDataManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(LolEventDataManagementApplication.class, args);
    }

}
