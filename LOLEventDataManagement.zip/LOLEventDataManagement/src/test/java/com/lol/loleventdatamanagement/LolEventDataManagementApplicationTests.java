package com.lol.loleventdatamanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LolEventDataManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
